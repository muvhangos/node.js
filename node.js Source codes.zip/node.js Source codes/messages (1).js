//Listing 2.1
"use strict"; // Enforces stricter parsing and error handling in JavaScript

// Create an array of messages
let messages = [
    "A change of environment can be a good thing!", // Encouraging message about adaptability
    "You will make it!",                            // Motivational message
    "Just run with the code!"                       // Playful message encouraging action
];

// Loop through the messages and log each one
messages.forEach(m => console.log(m));




