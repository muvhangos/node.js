const addition = require('./add');

addition.addNum(10, 15);