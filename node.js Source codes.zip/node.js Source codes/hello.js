"use strict";

console.log("Hello, Universe!");